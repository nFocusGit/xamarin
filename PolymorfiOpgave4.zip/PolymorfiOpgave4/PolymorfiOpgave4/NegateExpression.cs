﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorfiOpgave4
{
    class NegateExpression : UnaryExpression
    {
        public override double Evaluate()
        {
            throw new NotImplementedException();
        }
    }
}
